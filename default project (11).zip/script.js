// Placeholder data storage using localStorage
let studioTimes = JSON.parse(localStorage.getItem('studioTimes')) || [];
let leads = JSON.parse(localStorage.getItem('leads')) || [];
let contentPlans = JSON.parse(localStorage.getItem('contentPlans')) || [];

function updateLocalStorage() {
    localStorage.setItem('studioTimes', JSON.stringify(studioTimes));
    localStorage.setItem('leads', JSON.stringify(leads));
    localStorage.setItem('contentPlans', JSON.stringify(contentPlans));
}

// Function to update the chart
function updateChart() {
    const ctx = document.getElementById('studioTimeChart').getContext('2d');
    const labels = studioTimes.map(time => time.date);
    const data = studioTimes.map(time => time.hours);

    if (window.studioTimeChart) {
        window.studioTimeChart.data.labels = labels;
        window.studioTimeChart.data.datasets[0].data = data;
        window.studioTimeChart.update();
    } else {
        window.studioTimeChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Hours Spent in Studio',
                    data: data,
                    backgroundColor: 'rgba(255, 99, 132, 0.2)',
                    borderColor: 'rgba(255, 99, 132, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    }
}

// Function to render lists
function renderLists() {
    const studioTimeList = document.getElementById('studioTimeList');
    const leadList = document.getElementById('leadList');
    const contentList = document.getElementById('contentList');

    studioTimeList.innerHTML = '';
    studioTimes.forEach((time, index) => {
        studioTimeList.innerHTML += `<li class="list-group-item">
            ${time.date}: ${time.hours}
